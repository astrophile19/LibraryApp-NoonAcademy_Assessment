package com.example.library;


/**
 *Created by nischal on 12/23/2019.
 */


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class User_Guide extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__guide);
    }
}
